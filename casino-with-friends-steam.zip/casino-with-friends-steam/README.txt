CASINO WITH FRIENDS - STEAM VERSION
==================================

This folder turns the game into a normal Windows program (an .exe) that can go on Steam.
A grown-up needs to do these steps, because Steam needs payment and tax details.

1) BUILD THE GAME PROGRAM (about 5 minutes, on a Windows PC)
   a. Install Node.js (the "LTS" version) from https://nodejs.org
   b. Open this folder, click the address bar, type  cmd  and press Enter.
   c. Type:  npm install       and press Enter (wait until it finishes).
   d. Type:  npm run dist      and press Enter.
   e. The game program appears in the "dist" folder:
        - "Casino With Friends Setup 1.0.0.exe"  (installer)
        - "Casino With Friends 1.0.0.exe"        (runs without installing)
   To just try it first, type:  npm start

2) PUT IT ON STEAM
   a. Sign up at https://partner.steamgames.com (Steamworks). It costs US$100 per game
      and asks for bank and tax details.
   b. Create the game ("app"), fill in the store page, and add the pictures Steam asks for.
   c. Upload the files from the "dist\win-unpacked" folder as the game build
      (Steamworks has an upload tool called SteamPipe; its guide walks you through it).
      Set the launch program to "Casino With Friends.exe".
   d. Send it for Valve's review. When it passes, you can release it.

NOTES
- The game needs the internet the first time it starts (it loads its 3D engine and fonts online),
  and for parties with friends.
- Saves are kept on each computer.
- To update the game later, replace game\index.html with the new one and run  npm run dist  again.

- cover.jpg is the game picture, handy for the Steam store page.
